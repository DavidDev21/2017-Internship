
<?php
	require "devServerConnection.php";
	
	
	// Times on the queue
	// $queueDisplay gives the number of items from the mysql table to display
	// $itemPerPage is the CONST var for max number of elements to display per page
	$queueDisplay = $_POST['queueCounter'];
	$itemPerPage = $_POST['itemPerPage'];

	$noResult = False;
	// queueDisplay = will be the "starting row" for the MYSQL query
	$sql_query = "SELECT * FROM `Queue_Table` ORDER BY `Queue ID` ASC LIMIT ".$queueDisplay.",".$itemPerPage;
	$result = mysqli_query($connection,$sql_query);

	// offset is used to account for the out-of-range sql_queries that have no result
	// Only used when correcting the queueCounter value on javascript via php echo
	$offset = 0;

	// Just show everything left Seems super redundant. (Doesn't let user to load more if there isn't anymore to load)
	while(mysqli_num_rows($result) == 0)
	{
		++$offset;
		$noResult = True;

		// Performs the correction needed to ensure there is something to display
		$queueDisplay -= $itemPerPage;

		$sql_query = "SELECT * FROM `Queue_Table` ORDER BY `Queue ID` ASC LIMIT ".$queueDisplay.",".$itemPerPage;
		$result = mysqli_query($connection,$sql_query);
	}

	/* No longer needed in loadQueue.php (this is all in refresh Table.php)
	//echo $result;
	// If there is anything from the result
	if(mysqli_num_rows($result)>0)
	{	
		// STOP IGNORING MY HTML TAGSSSSSSS
		echo "<tbody>";
		// Recreates the header (probably not the best way)
		echo	"<tr>
					<th class = \"table-header\">Queue Number</th>
					<th class = \"table-header\">Design Title</th>
					<th class = \"table-header\">Related Project</th>
					<th class = \"table-header\">File</th>
					<th class = \"table-header\">Last Modified</th>
			 	</tr>";
		while($row = mysqli_fetch_assoc($result))
		{
			echo "<tr class=\"table-row\">";
			echo "<td>";
			echo $row['Queue ID'];
			echo "</td>";

			echo "<td>";
			echo $row['Design Title'];
			echo "</td>";

			echo "<td>";
			echo $row['Related Project'];
			echo "</td>";

			echo "<td>";
			// Useful variable. (Just a slight performance optimization)
			$filePath = $row['File Path'];

			// Gives the position of where the file name actually starts
			// from the full file path
			$file_name_pos = strrpos($filePath,'/');

			// Since the full path is stored on the database (For ease of use on the server side code)
			// We must grab the filename from the full path
			if($file_name_pos == False)
			{
				echo substr($filePath,$file_name_pos);
			}
			else
			{
				// The result should just be the file name
				$temp = substr($filePath,$file_name_pos+1); // Spare me the bad variable name
				if($temp != "")
				{
					echo $temp;
				}
				else
				{
					echo "No File Found";
				}
			}

			echo "</td>";

			echo "<td>";
			echo $row['Last Date Modified'];
			echo "</td>";
			echo "</tr>";
		}
		echo "</tbody>";
	}
	else
	{
		echo "<h1 id=\"noResult\">NO RESULT TO DISPLAY</h1>";
	}
	*/
	if($noResult)
	{
		echo "<script>";
		echo "alert(\"No more result to load\");";
		echo "queueItemCount = queueItemCount - (ITEMS_PER_PAGE * ".$offset.");";
		echo "</script>";

		// Safety procaution. Making sure the variable get reset.
		$noResult = False;
	}
	else
	{
		echo "<script>";
		echo "queueItemCount = queueItemCount + ITEMS_PER_PAGE;";
		echo "</script>";
	}
	mysqli_close($connection);


?>