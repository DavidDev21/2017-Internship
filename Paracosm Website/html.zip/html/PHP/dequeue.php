<?php

	//	File: dequeue.php
	//	Author: David Zheng
	//	Last Updated Date: 8/18/2017

	// PHP script that handles the offloading of queue elements
	
	// "devServerConnection.php" is pretty much needed for any interaction with server
	// It has all the infomation and setup needed
	require "devServerConnection.php";

	// Grab the first record on the table to dequeue
	$sql_query = "SELECT * FROM `Queue_Table` ORDER BY `Queue ID` ASC LIMIT 1";
	$result = mysqli_query($connection,$sql_query);

	$dequeueElement = mysqli_fetch_assoc($result);

// ======================================================================================
	// Checks if a record even exists
	if($dequeueElement)
	{
		// The target_folder would be the Paracosm folder if the system was fully deployed
		$target_folder = "/home/mygod/Desktop/dummyParacosmTrash/"; // current path on the VM
		$source_folder = $dequeueElement['File Path']; //Should have the full file path stored on the database

		// (Copied from loadQueue.php)
		// Grabs just the file name from the full file path
		// Useful variable. (Just a slight performance optimization)
		$filePath = $dequeueElement['File Path'];

		// Gives the position of where the file name actually starts
		// from the full file path
		$file_name_pos = strrpos($filePath,'/');

		// Since the full path is stored on the database (For ease of use on the server side code)
		// We must grab the filename from the full path
		if($file_name_pos == False)
		{
			$filePath = substr($filePath,$file_name_pos);
		}
		else
		{
			// The result should just be the file name
			$temp = substr($filePath,$file_name_pos+1); // Spare me the bad variable name
			if($temp != "")
			{
				$filePath = $temp;
			}
			else
			{
				echo "<script>";
				echo "alert(\"No File to Dequeue\");";
				echo "</script>";
			}
		}

// ======================================================================================
		// Clear everything that might be in the target folder
		$targetFiles = glob($target_folder."*");

		// Deletes all files in the target directory
		foreach($targetFiles as $file)
		{
			if(is_file($file))
			{
				unlink($file); // Deletes the file
			}
		}

// ======================================================================================
		// Moves the source file to target destination
		// Works. This is promised an existing file. devTest.php guarantees this premise
		copy($source_folder,$target_folder.$filePath);

		// Copies the queue record to another table for tracking purposes (History_Table)

		$sql_query = "INSERT INTO `History_Table` (`Queue ID`, `Design Title`, `Related Project`,`File Path`, `Author`) SELECT `Queue ID`, `Design Title`, `Related Project`,`File Path`, `Author` FROM `Queue_Table` LIMIT 1";
		$result = mysqli_query($connection,$sql_query);
		
		// removes the element from the database record (Mind not need two parameters for LIMIT)
		$sql_query = "DELETE FROM `Queue_Table` LIMIT 1";
		$result = mysqli_query($connection,$sql_query);

		// Does not need error check cause the if statement guarentees that there is a record to be deleted
// ======================================================================================
		// Refresh the table
		//require "refreshTable.php";
	}
	else
	{
		echo "<script>";
		echo "alert(\"No File to Dequeue\");";
		echo "</script>";
	}
?>