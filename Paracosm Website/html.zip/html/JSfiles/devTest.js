"use strict";


let myName = "David. This backtick thing works";

alert(`Hello, My name is ${myName}`);


/*
	AJax form submission (Add design file)

function formSubmit()
{
	let designName = document.getElementById("designName");
	let relatedProject = document.getElementById("relatedProject");
	let designFile = document.getElementById("designFileUpload");

	if(designName.value == '' || relatedProject.value == '')
	{
		alert("PLEASE ENTER EVERYTHING");
	}
	else
	{
		$.ajax(
		{
			type: "POST",
			url: "PHP/devTest.php",
			data: 
		})
	}
}
*/